
<?php $__env->startSection('title', 'Messages'); ?>
<?php $__env->startSection('content'); ?>

<div class="w3-container w3-content w3-padding-64">
    <div class="w3-container">
        <h1 class="w3-center">Your Messages</h1>

        <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
        <div class="w3-card-4 w3-padding-16">

            <header class="w3-container w3-light-grey">
              <h3><?php echo e($msg->name); ?></h3>
            </header>
            
            <div class="w3-container">
              <p><?php echo e($msg->message); ?></p>
              <hr>
              <p><?php echo e($msg->email); ?> IP: <?php echo e($msg->ipaddress); ?></p>
            </div>

            <form action="<?php echo e(route('message_delete',$msg->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
            <button class="w3-button w3-block w3-dark-grey" type="submit">- Delete</button>
            </form>
        </div>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        

    </div>
    

</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.nonindex', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Programs\xampp\htdocs\portfolio\resources\views/messages/viewallmessages.blade.php ENDPATH**/ ?>