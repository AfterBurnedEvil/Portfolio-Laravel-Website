<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>TESTT</title>
  <link href=" <?php echo e(URL::asset('css/w3.css')); ?>" rel="stylesheet">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Allerta+Stencil">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>

.w3-Allerta {
  font-family: 'Allerta Stencil', sans-serif;
}

body, h1, h2, h3, h4, h5, h6  {
  font-family: Roboto, sans-serif;
}
</style>

</head>
<body>

  <header>
  </header>
<div>
    <div class="w3-bar w3-border w3-white" id="myNavbar">
    
    <span class="w3-bar-item w3-Allerta">Akshay Jose Portfolio</span>
    <a href="<?php echo e(route('home')); ?>" class="w3-bar-item w3-button w3-mobile w3-hover-green w3-hide-small">Home</a>
    <a href="#" class="w3-bar-item w3-button w3-mobile w3-hover-green w3-hide-small">Projects</a>
    <a href="#" class="w3-bar-item w3-button w3-mobile w3-blue w3-hide-small">Download Resume</a>
    <a class="w3-bar-item w3-button w3-hover-black w3-hide-medium w3-hide-large w3-right" href="javascript:void(0);" onclick="toggleFunction()" title="Toggle Navigation Menu">
        <i class="fa fa-bars"></i>
      </a>
      <?php if(auth()->guard()->check()): ?>
            <a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();" class="w3-bar-item w3-button w3-mobile w3-blue w3-hide-small w3-right">Logout</a>
      
      <?php else: ?>
      <a href="<?php echo e(route('login')); ?>" class="w3-bar-item w3-button w3-mobile w3-hover-green w3-hide-small w3-right">Login</a>
      <?php endif; ?>
    </div>

    <!-- Navbar on small screens -->
    <div id="navDemo" class="w3-bar-block w3-white w3-hide w3-hide-large w3-hide-medium">
      <a href="#about" class="w3-bar-item w3-button" onclick="toggleFunction()">Home</a>
      <a href="#portfolio" class="w3-bar-item w3-button" onclick="toggleFunction()">Music</a>
      <a href="#contact" class="w3-bar-item w3-button" onclick="toggleFunction()">Download Resume</a>
    </div>

</div>
 

<?php echo $__env->yieldContent('content'); ?>


<form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
    <?php echo e(csrf_field()); ?>

</form>


<script>

// Used to toggle the menu on small screens when clicking on the menu button
function toggleFunction() {
    var x = document.getElementById("navDemo");
    if (x.className.indexOf("w3-show") == -1) {
        x.className += " w3-show";
    } else {
        x.className = x.className.replace(" w3-show", "");
    }
}
</script>
</body>




</html><?php /**PATH E:\xampp\htdocs\portfolio\resources\views/layouts/nonindex.blade.php ENDPATH**/ ?>