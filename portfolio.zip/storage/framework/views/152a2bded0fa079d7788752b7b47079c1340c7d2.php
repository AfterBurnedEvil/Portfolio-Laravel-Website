
<?php $__env->startSection('content'); ?>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.nonindex', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Programs\xampp\htdocs\portfolio\resources\views/project/viewallproject.blade.php ENDPATH**/ ?>