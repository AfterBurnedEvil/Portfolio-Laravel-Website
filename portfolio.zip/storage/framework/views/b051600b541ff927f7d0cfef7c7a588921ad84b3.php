
<?php $__env->startSection('content'); ?>

<div class="w3-content w3-container w3-padding-64 w3-border w3-margin-top">
    <h1 class="w3-center"> Role Test</h1>
    <?php if(auth()->guard()->check()): ?>
    <?php echo e(Auth::user()->name); ?>

    <?php echo e(Auth::user()->password); ?>

    <?php echo e(Auth::user()->username); ?>

    <?php echo e(Auth::user()->role); ?>


    <?php if(Auth::user()->role == "norm"): ?>
    <p>Role : Normal</p>
    <?php endif; ?>
    <?php else: ?>
    not logged in
    <?php endif; ?>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isAdminn')): ?>
    TestB
    <?php endif; ?>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.nonindex', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Programs\xampp\htdocs\portfolio\resources\views/homee/test.blade.php ENDPATH**/ ?>