
<?php $__env->startSection('content'); ?>

<div class="w3-sidebar w3-light-grey w3-bar-block" style="width:15%">
  <h3 class="w3-bar-item">Menu</h3>
  <a href="<?php echo e(route('dboard')); ?>" class="w3-bar-item w3-button">Dashboard</a>
  <a href="<?php echo e(route('skillz_show')); ?>" class="w3-bar-item w3-button">Skills</a>
  <a href="<?php echo e(route('dbio')); ?>" class="w3-bar-item w3-button">My Bio</a>
  <a href="<?php echo e(route('skille_view', auth()->user()->id)); ?>" class="w3-bar-item w3-button w3-green">My Skills</a>
</div>
<div style="margin-left:15%">


<div class="w3-container w3-blue">
  <h1>Skills</h1>
</div>
<div class="w3-content">

<form class="w3-container w3-card-4 w3-light-grey" action="<?php echo e(route('myskillz_store')); ?>" method="POST">
<?php echo csrf_field(); ?>
<h3>Skills:</h3>
<?php $__currentLoopData = $skillnames; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


<label><?php echo e($skill['name']); ?> </label>
<input type="hidden" name="skillid[]" value="<?php echo e($skill['skill_id']); ?>">
<input class="w3-input w3-border-0" type="text" name="value[]" value="<?php echo e($skill['value']); ?>"></p>

  
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<button class="w3-button w3-round-xlarge w3-blue w3-margin" type="submit">Submit</button> <br>
</form>
</div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.nonindex', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\portfolio\resources\views/admin/myskills.blade.php ENDPATH**/ ?>