
<?php $__env->startSection('title', 'Create Project'); ?>
<?php $__env->startSection('content'); ?>

<div class="w3-container">

    <form method="POST" action="<?php echo e(route('project_store')); ?>" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <h2>Create a New Project</h2>
        <p>Use this to create a new project information.</p>
      
        <p>
        <label>Title</label>
        <input class="w3-input w3-border w3-round" name="title" type="text"></p>
        <p>
        <label>Image</label><br>
        <input type="file" name="imgz">
        <p>
        <label>Body</label>
        <textarea style="height: 150px; resize: none;" class="ckeditor" name="body" type="textarea"></textarea></p>
        <button class="w3-button w3-round-xlarge w3-blue" type="submit">Submit</button> <br>
      </form>

    <?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
    <?php endif; ?>

</div>

<script src="//cdn.ckeditor.com/4.14.0/standard/ckeditor.js"></script>
<script type="text/javascript">
    $(document).ready(function() {
       $('.ckeditor').ckeditor();
    });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.nonindex', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Programs\xampp\htdocs\portfolio\resources\views/project/createproject.blade.php ENDPATH**/ ?>