
<?php $__env->startSection('content'); ?>
<style>
/* Create a Parallax Effect */
.bgimg-1 {
  background-attachment: fixed;
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;
}

/* First image (Logo. Full height) */
.bgimg-1 {
  background-image: url('../img/test.png');
  min-height: 80%;

}

body, html {
  height: 100%;
  color: #777;
  line-height: 1.8;
}

.w3-wide {letter-spacing: 10px;}
.w3-hover-opacity {cursor: pointer;}

/* Turn off parallax scrolling for tablets and phones */
@media  only screen and (max-device-width: 1600px) {
  .bgimg-1{
    background-attachment: scroll;
    min-height: 400px;
  }
}

</style>

<!-- First Parallax Image with Logo Text -->
<div class="bgimg-1 w3-display-container w3-opacity-min">
  <div class="w3-display-middle" style="white-space:nowrap;">
    <span class="w3-center w3-padding-large w3-black w3-xlarge w3-wide w3-animate-opacity">MY<span class="w3-hide-small"></span> RESUME</span>
  </div>
</div>

<div class="w3-container">



<div class="w3-content w3-container w3-padding-64">
<h1 class="w3-center">About Me</h1>
<p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Hic, perferendis. Nesciunt suscipit quia blanditiis dolore harum atque nulla cumque porro labore? Ipsa, natus illo obcaecati perferendis quaerat asperiores autem eum?</p>
    <div class="w3-row">
        <div class="w3-col m4 l4">
        <img src="../img/propic.jpg">
        </div>
    <div class="w3-col m6 l6">
    <p><i class="fa fa-birthday-cake"></i> Birthday : <?php echo e($details->dob); ?></p>
    <p><i class="fa fa-map-pin"></i> Hometown : <?php echo e($details->hometown); ?></p>
    <p><i class="fa fa-envelope"></i> Email : <?php echo e($details->email); ?></p>
</div>

</div>
<div class="w3-content w3-container w3-padding-64">
<h1 class="w3-center">My Skills</h1>
    <?php $__currentLoopData = $skillnames; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <p><?php echo e($skill['name']); ?> </p>
    <div class="w3-light-grey w3-round w3-animate-opacity">
    <div class="w3-container w3-round w3-blue" style="width:<?php echo e($skill['value']); ?>%"><?php echo e($skill['value']); ?>%</div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>

<div class="w3-content w3-container w3-padding-64">
<h1 class="w3-center">My Projects</h1>
    <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Eos dolorem assumenda, ex nam ut, repellat corporis maxime obcaecati tempora veniam consectetur culpa animi possimus sint aliquam vel recusandae maiores suscipit.</p>
    
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\portfolio\resources\views/homee/index.blade.php ENDPATH**/ ?>